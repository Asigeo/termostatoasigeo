sudo python3 ScreenTimer.py >> logs/logpant.txt  &
python3 Main1Pant.py >> logs/logsapp.txt
