#!/bin/bash

PATH_DIR="/home/pi/ASIGEO/"
ZIP="ASIGEO.zip"

echo "Realizando instalación de equipo ASIGEO"
echo "==========================================================="
echo "==========================================================="
sleep 1

echo "El directorio de despliegue será: " $PATH_DIR
sleep 1

if [ ! -d $PATH_DIR ]
then 
	sudo mkdir $PATH_DIR
fi

if [ ! -f "ASIGEO.zip" ]
then
	echo "No se encontro el fichero zip para la instalación"
	sleep 1
	exit 1
fi

echo "Ahora se procede a la instalación de nueva verisión"

echo "Removiendo antigua versión de App"
sleep 1
sudo rm -r $PATHDIR"/*"
echo "Versión antigua eliminada"
sleep 1

echo "Copiando zip con nueva versión de ASIGEO a directorio de despliegue"
sleep 1
sudo cp $ZIP $PATH_DIR
echo "Copiado zip con nueva versión"
sleep 1

echo "Extrayendo nueva versión de App"
sleep 1
sudo unzip -d $PATH_DIR$ZIP
echo "App ASIGEO extraida"
sleep 1

echo "Peticion de token para device"
sleep 1
echo "[Escriba: La contraseña que desee para su dispositivo]"
read -p "Quiere establecer como contraseña esta?\n"$OPTION  -n 1 -r
if [[ $REPLY ]]
then
	sudo echo "[SECURITY]" > PATHDIR"/config.ini"
    echo "token="$REPLY >> PATHDIR"/config.ini"
fi

echo "Estableciendo App para que se ejecute en boot"
sleep 1
if [ ! -f "/etc/rc.local" ]
then 
	echo "Fichero rc.local no existe en el equipo"
	exit 1
else
	echo "_IP=\$(hostname -I) || true" > /etc/rc.local
	echo "if [ \"$_IP\" ]; then" >> /etc/rc.local
	echo "\tprintf \"My IP address is %s\n\" \"$_IP\"" >> /etc/rc.local
	echo "fi"

	echo "sudo python3 /home/pi/ASIGEOINAR/server.py &" >> /etc/rc.local
	echo "sudo python3 /home/pi/ASIGEOINAR/Main1Pant.py &" >> /etc/rc.local
	echo "sudo python3 /home/pi/ASIGEOINAR/ScreenTimer.py &" >> /etc/rc.local

	echo "exit 0" >> /etc/rc.local
fi

echo "Instalacion terminada"
sleep 1
echo "[Escribe: [Y|y] para confirmar u otra caso para denegar]"
read -p "Quiere reiniciar ahora?\n"$OPTION  -n 1 -r
if [[ $REPLY =~ ^[Yy]$ ]]
then
    sudo reboot
fi