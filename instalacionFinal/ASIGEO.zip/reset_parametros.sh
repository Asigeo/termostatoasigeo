rm /boot/pi/json_f/*
cp /boot/pi/sec_copy/* /boot/pi/json_f
sudo reboot